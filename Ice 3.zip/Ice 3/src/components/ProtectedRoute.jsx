import React from 'react';
import { Navigate } from 'react-router-dom';
import { isLoggedIn, getToken, isTokenExpired } from '../utils/auth';

const ProtectedRoute = ({ children }) => {
  const userIsLoggedIn = isLoggedIn();
  const token = getToken();
  
  // Check if user is logged in and token is valid
  if (!userIsLoggedIn || !token || isTokenExpired(token)) {
    // Redirect to login page with a message
    return <Navigate to="/login" replace />;
  }

  // If authenticated, render the protected component
  return children;
};

export default ProtectedRoute;

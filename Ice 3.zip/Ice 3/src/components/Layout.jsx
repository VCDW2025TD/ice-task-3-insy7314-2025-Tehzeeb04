import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { isLoggedIn } from '../utils/auth';
import './Layout.css';

const Layout = ({ children }) => {
  const location = useLocation();
  const userIsLoggedIn = isLoggedIn();

  const isActive = (path) => {
    return location.pathname === path ? 'active' : '';
  };

  return (
    <div className="layout">
      <nav className="navbar">
        <div className="nav-container">
          <Link to="/" className="nav-logo">
            Ice 3 Auth
          </Link>
          
          <ul className="nav-menu">
            <li className="nav-item">
              <Link to="/" className={`nav-link ${isActive('/')}`}>
                Home
              </Link>
            </li>
            
            {userIsLoggedIn ? (
              // Logged in navigation
              <>
                <li className="nav-item">
                  <Link to="/dashboard" className={`nav-link ${isActive('/dashboard')}`}>
                    Dashboard
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/logout" className={`nav-link ${isActive('/logout')}`}>
                    Logout
                  </Link>
                </li>
              </>
            ) : (
              // Logged out navigation
              <>
                <li className="nav-item">
                  <Link to="/register" className={`nav-link ${isActive('/register')}`}>
                    Register
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/login" className={`nav-link ${isActive('/login')}`}>
                    Login
                  </Link>
                </li>
              </>
            )}
          </ul>
        </div>
      </nav>
      
      <main className="main-content">
        {children}
      </main>
      
      <footer className="footer">
        <div className="footer-container">
          <p>&copy; 2025 Ice 3 Authentication App. Built with React & JWT.</p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;

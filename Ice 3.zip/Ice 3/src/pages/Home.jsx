import React from 'react';
import { Link } from 'react-router-dom';
import { isLoggedIn } from '../utils/auth';
import './Home.css';

const Home = () => {
  const userIsLoggedIn = isLoggedIn();

  return (
    <div className="home-container">
      <div className="hero-section">
        <h1>Welcome to Ice 3 Authentication</h1>
        <p className="hero-subtitle">
          A complete React authentication system with JWT tokens, protected routes, and secure user management.
        </p>
        
        {userIsLoggedIn ? (
          <div className="logged-in-actions">
            <p className="welcome-back">Welcome back! You are currently logged in.</p>
            <Link to="/dashboard" className="cta-button">
              Go to Dashboard
            </Link>
          </div>
        ) : (
          <div className="logged-out-actions">
            <p className="get-started">Get started by creating an account or logging in.</p>
            <div className="action-buttons">
              <Link to="/register" className="cta-button primary">
                Get Started
              </Link>
              <Link to="/login" className="cta-button secondary">
                Login
              </Link>
            </div>
          </div>
        )}
      </div>

      <div className="features-section">
        <h2>Features</h2>
        <div className="features-grid">
          <div className="feature-card">
            <h3>🔐 Secure Authentication</h3>
            <p>JWT-based authentication with secure token storage and automatic expiration handling.</p>
          </div>
          
          <div className="feature-card">
            <h3>🛡️ Protected Routes</h3>
            <p>Route-level protection ensuring only authenticated users can access secure areas.</p>
          </div>
          
          <div className="feature-card">
            <h3>📱 Responsive Design</h3>
            <p>Modern, mobile-first design that works perfectly on all device sizes.</p>
          </div>
          
          <div className="feature-card">
            <h3>⚡ React Router</h3>
            <p>Client-side routing with React Router for seamless navigation experience.</p>
          </div>
          
          <div className="feature-card">
            <h3>🔄 Auto Token Refresh</h3>
            <p>Automatic token validation and refresh to maintain user sessions securely.</p>
          </div>
          
          <div className="feature-card">
            <h3>🎨 Modern UI</h3>
            <p>Clean, professional interface with consistent styling and smooth interactions.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;

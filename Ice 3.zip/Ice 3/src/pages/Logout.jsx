import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { removeToken } from '../utils/auth';
import './Logout.css';

const Logout = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Clear the token from localStorage
    removeToken();
    
    // Redirect to home page after a short delay
    const timer = setTimeout(() => {
      navigate('/');
    }, 2000);

    // Cleanup timer on component unmount
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="logout-container">
      <div className="logout-content">
        <h1>Logging Out</h1>
        <p>You have been successfully logged out.</p>
        <p>Redirecting to home page...</p>
        <div className="logout-spinner"></div>
      </div>
    </div>
  );
};

export default Logout;

import React, { useState, useEffect } from 'react';
import { getToken, decodeToken } from '../utils/auth';
import API from '../services/api';
import './Dashboard.css';

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const token = getToken();
        if (token) {
          // Decode token to get user info
          const decoded = decodeToken(token);
          setUser(decoded);
        }

        // Optional: Fetch additional user data from API
        // const response = await API.get('/user/profile');
        // setUser(response.data);
        
      } catch (error) {
        console.error('Error fetching user data:', error);
        setError('Failed to load user data');
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, []);

  if (loading) {
    return (
      <div className="dashboard-container">
        <div className="loading-message">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="dashboard-container">
        <div className="error-message">{error}</div>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <h1>Dashboard</h1>
        <p className="welcome-message">
          Welcome to your secure dashboard!
        </p>
      </div>

      <div className="dashboard-content">
        <div className="user-info-card">
          <h2>User Information</h2>
          {user ? (
            <div className="user-details">
              <p><strong>Email:</strong> {user.email || 'Not available'}</p>
              <p><strong>User ID:</strong> {user.sub || user.id || 'Not available'}</p>
              <p><strong>Login Time:</strong> {user.iat ? new Date(user.iat * 1000).toLocaleString() : 'Not available'}</p>
              <p><strong>Token Expires:</strong> {user.exp ? new Date(user.exp * 1000).toLocaleString() : 'Not available'}</p>
            </div>
          ) : (
            <p>User information not available</p>
          )}
        </div>

        <div className="features-card">
          <h2>Available Features</h2>
          <ul className="features-list">
            <li>✅ Secure Authentication</li>
            <li>✅ Protected Routes</li>
            <li>✅ JWT Token Management</li>
            <li>✅ Automatic Token Validation</li>
            <li>✅ Session Management</li>
          </ul>
        </div>

        <div className="actions-card">
          <h2>Quick Actions</h2>
          <div className="action-buttons">
            <button 
              className="action-button" 
              onClick={() => window.location.reload()}
            >
              Refresh Data
            </button>
            <button 
              className="action-button secondary" 
              onClick={() => console.log('Feature coming soon!')}
            >
              Update Profile
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

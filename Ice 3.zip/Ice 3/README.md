# Ice 3 - React Authentication System

A complete React frontend authentication system with JWT tokens, protected routes, and secure user management.

## 🚀 Features

- ✅ **User Registration** - Create new accounts with email/password
- ✅ **User Login** - Secure authentication with JWT tokens
- ✅ **Protected Routes** - Route-level protection for authenticated users
- ✅ **Dashboard** - Secure user dashboard with profile information
- ✅ **Logout** - Clear sessions and redirect users
- ✅ **Responsive Design** - Mobile-first, modern UI
- ✅ **Token Management** - Automatic token validation and expiration handling
- ✅ **Error Handling** - Comprehensive error messages and feedback
- ✅ **Modern React** - Built with React 18, React Router 6, and Axios

## 📦 Installation

### Prerequisites

Make sure you have Node.js installed on your system. You can download it from [nodejs.org](https://nodejs.org/).

### Setup

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start the development server:**
   ```bash
   npm start
   ```

3. **Open your browser:**
   Navigate to `http://localhost:3000`

## 🏗️ Project Structure

```
src/
├── components/
│   ├── Layout.jsx          # Main layout with navigation
│   ├── Layout.css
│   ├── ProtectedRoute.jsx  # Route protection component
├── pages/
│   ├── Home.jsx           # Landing page
│   ├── Home.css
│   ├── Login.jsx          # Login page
│   ├── Login.css
│   ├── Register.jsx       # Registration page
│   ├── Register.css
│   ├── Dashboard.jsx      # Protected dashboard
│   ├── Dashboard.css
│   ├── Logout.jsx         # Logout page
│   └── Logout.css
├── services/
│   └── api.js             # Axios configuration with interceptors
├── utils/
│   └── auth.js            # Authentication utility functions
├── App.jsx                # Main app component with routing
├── App.css                # Global styles
└── index.js               # React app entry point
```

## 🔧 API Configuration

The frontend is configured to connect to a backend API at `https://localhost:5000/api`. 

### Required Backend Endpoints

Your backend should provide these endpoints:

- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login

### Request/Response Format

**Registration Request:**
```json
{
  "email": "user@example.com",
  "password": "securepassword"
}
```

**Login Request:**
```json
{
  "email": "user@example.com",
  "password": "securepassword"
}
```

**Success Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Error Response:**
```json
{
  "message": "Invalid credentials",
  "error": "Authentication failed"
}
```

## 🛡️ Security Features

### JWT Token Management
- Automatic token storage in localStorage
- Token included in all authenticated requests
- Automatic token expiration checking
- Redirect to login on token expiration

### Route Protection
- Protected routes require valid authentication
- Automatic redirect to login for unauthorized access
- Token validation on protected route access

### Input Validation
- Client-side form validation
- Required field validation
- Email format validation
- Password minimum length requirements

## 📱 Responsive Design

The application is fully responsive and includes:
- Mobile-first design approach
- Responsive navigation
- Flexible grid layouts
- Touch-friendly interactions
- Optimized for all screen sizes

## 🎨 Styling

The application uses modern CSS with:
- CSS Grid and Flexbox layouts
- CSS custom properties (variables)
- Smooth transitions and animations
- Consistent color scheme
- Professional typography

## 🔄 State Management

Authentication state is managed through:
- localStorage for token persistence
- React state for component-level state
- Utility functions for authentication checks
- Automatic state synchronization

## 🚀 Available Scripts

In the project directory, you can run:

### `npm start`
Runs the app in development mode. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

### `npm build`
Builds the app for production to the `build` folder.

### `npm test`
Launches the test runner in interactive watch mode.

### `npm eject`
**Note: this is a one-way operation. Once you `eject`, you can't go back!**

## 🔧 Customization

### Changing API Base URL
Edit `src/services/api.js` to change the backend URL:
```javascript
const API = axios.create({
  baseURL: "https://your-api-url.com/api",
  // ...
});
```

### Styling Customization
- Edit CSS files in the respective component folders
- Modify `src/App.css` for global styles
- Update color scheme in CSS custom properties

### Adding New Protected Routes
1. Create your component in `src/pages/`
2. Add the route in `src/App.jsx`:
```javascript
<Route 
  path="/your-route" 
  element={
    <ProtectedRoute>
      <YourComponent />
    </ProtectedRoute>
  } 
/>
```
3. Add navigation link in `src/components/Layout.jsx`

## 🐛 Troubleshooting

### Common Issues

**CORS Errors:**
- Ensure your backend has CORS configured to allow requests from `http://localhost:3000`

**Token Issues:**
- Check browser developer tools for token storage in localStorage
- Verify token format and expiration

**Network Errors:**
- Confirm backend is running on the correct port
- Check SSL configuration if using HTTPS

**Build Errors:**
- Run `npm install` to ensure all dependencies are installed
- Check for any missing imports or syntax errors

## 📚 Dependencies

- **React** (^18.2.0) - UI library
- **React Router DOM** (^6.11.0) - Client-side routing
- **Axios** (^1.4.0) - HTTP client
- **React Scripts** (5.0.1) - Build tools

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 💡 Next Steps

- [ ] Add password strength validation
- [ ] Implement "Remember Me" functionality
- [ ] Add password reset feature
- [ ] Implement email verification
- [ ] Add user profile editing
- [ ] Implement refresh tokens
- [ ] Add social login options
- [ ] Add two-factor authentication

---

Built with ❤️ using React, JWT, and modern web technologies.
